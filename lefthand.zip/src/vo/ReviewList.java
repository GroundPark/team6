package vo;

public class ReviewList {
	private int rl_idx, rl_score, rl_good, rl_point;
	private String mi_id,poi_id, pi_id, rl_content, rl_img, rl_isview, rl_date;
	public int getRl_idx() {
		return rl_idx;
	}
	public void setRl_idx(int rl_idx) {
		this.rl_idx = rl_idx;
	}
	public int getRl_score() {
		return rl_score;
	}
	public void setRl_score(int rl_score) {
		this.rl_score = rl_score;
	}
	public int getRl_good() {
		return rl_good;
	}
	public void setRl_good(int rl_good) {
		this.rl_good = rl_good;
	}
	public int getRl_point() {
		return rl_point;
	}
	public void setRl_point(int rl_point) {
		this.rl_point = rl_point;
	}
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getPoi_id() {
		return poi_id;
	}
	public void setPoi_id(String poi_id) {
		this.poi_id = poi_id;
	}
	public String getPi_id() {
		return pi_id;
	}
	public void setPi_id(String pi_id) {
		this.pi_id = pi_id;
	}
	public String getRl_content() {
		return rl_content;
	}
	public void setRl_content(String rl_content) {
		this.rl_content = rl_content;
	}
	public String getRl_img() {
		return rl_img;
	}
	public void setRl_img(String rl_img) {
		this.rl_img = rl_img;
	}
	public String getRl_isview() {
		return rl_isview;
	}
	public void setRl_isview(String rl_isview) {
		this.rl_isview = rl_isview;
	}
	public String getRl_date() {
		return rl_date;
	}
	public void setRl_date(String rl_date) {
		this.rl_date = rl_date;
	}
	
}
