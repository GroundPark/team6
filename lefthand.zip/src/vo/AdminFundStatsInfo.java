﻿package vo;

public class AdminFundStatsInfo {
// 펀딩 단계별 개수를 저장 할 클래스
	private int s1ac, s1bc, s2ac, s2bc, s2cc;
	// 각 글자는 step / 차수 / status / 상태값을 의미

	public int getS1ac() {
		return s1ac;
	}

	public void setS1ac(int s1ac) {
		this.s1ac = s1ac;
	}

	public int getS1bc() {
		return s1bc;
	}

	public void setS1bc(int s1bc) {
		this.s1bc = s1bc;
	}

	public int getS2ac() {
		return s2ac;
	}

	public void setS2ac(int s2ac) {
		this.s2ac = s2ac;
	}

	public int getS2bc() {
		return s2bc;
	}

	public void setS2bc(int s2bc) {
		this.s2bc = s2bc;
	}

	public int getS2cc() {
		return s2cc;
	}

	public void setS2cc(int s2cc) {
		this.s2cc = s2cc;
	}
	
	

}
