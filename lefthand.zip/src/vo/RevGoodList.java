package vo;

public class RevGoodList {
	private String mi_id,rg_date;
	private int rg_idx, rl_idx;
	
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getRg_date() {
		return rg_date;
	}
	public void setRg_date(String rg_date) {
		this.rg_date = rg_date;
	}
	public int getRg_idx() {
		return rg_idx;
	}
	public void setRg_idx(int rg_idx) {
		this.rg_idx = rg_idx;
	}
	public int getRl_idx() {
		return rl_idx;
	}
	public void setRl_idx(int rl_idx) {
		this.rl_idx = rl_idx;
	}
	
	
	

}
