package vo;

public class AdminChallengeReplyList {
	// 댓글에 대한 정보 어드민용
	private int cr_idx, ci_idx, crr_idx, ai_idx;
	private String mi_id, cr_content, cr_date, cr_isview, crr_status, crr_date, crr_opdate;
	public int getCr_idx() {
		return cr_idx;
	}
	public void setCr_idx(int cr_idx) {
		this.cr_idx = cr_idx;
	}
	public int getCi_idx() {
		return ci_idx;
	}
	public void setCi_idx(int ci_idx) {
		this.ci_idx = ci_idx;
	}
	public int getCrr_idx() {
		return crr_idx;
	}
	public void setCrr_idx(int crr_idx) {
		this.crr_idx = crr_idx;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getCr_content() {
		return cr_content;
	}
	public void setCr_content(String cr_content) {
		this.cr_content = cr_content;
	}
	public String getCr_date() {
		return cr_date;
	}
	public void setCr_date(String cr_date) {
		this.cr_date = cr_date;
	}
	public String getCr_isview() {
		return cr_isview;
	}
	public void setCr_isview(String cr_isview) {
		this.cr_isview = cr_isview;
	}
	public String getCrr_status() {
		return crr_status;
	}
	public void setCrr_status(String crr_status) {
		this.crr_status = crr_status;
	}
	public String getCrr_date() {
		return crr_date;
	}
	public void setCrr_date(String crr_date) {
		this.crr_date = crr_date;
	}
	public String getCrr_opdate() {
		return crr_opdate;
	}
	public void setCrr_opdate(String crr_opdate) {
		this.crr_opdate = crr_opdate;
	}
	
	
}
