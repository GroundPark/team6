package vo;

public class ReviewReportList {
	private int rr_idx, rl_idx, ai_idx;
	private String mi_id, rr_status, rr_date, rr_opdate;
	
	public int getRr_idx() {
		return rr_idx;
	}
	public void setRr_idx(int rr_idx) {
		this.rr_idx = rr_idx;
	}
	public int getRl_idx() {
		return rl_idx;
	}
	public void setRl_idx(int rl_idx) {
		this.rl_idx = rl_idx;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getRr_status() {
		return rr_status;
	}
	public void setRr_status(String rr_status) {
		this.rr_status = rr_status;
	}
	public String getRr_date() {
		return rr_date;
	}
	public void setRr_date(String rr_date) {
		this.rr_date = rr_date;
	}
	public String getRr_opdate() {
		return rr_opdate;
	}
	public void setRr_opdate(String rr_opdate) {
		this.rr_opdate = rr_opdate;
	}

}
