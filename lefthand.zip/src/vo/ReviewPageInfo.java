package vo;

public class ReviewPageInfo {
	private int rcpage, rpsize, rbsize, rspage, repage, rrcnt, rpcnt;

	public int getRcpage() {
		return rcpage;
	}

	public void setRcpage(int rcpage) {
		this.rcpage = rcpage;
	}

	public int getRpsize() {
		return rpsize;
	}

	public void setRpsize(int rpsize) {
		this.rpsize = rpsize;
	}

	public int getRbsize() {
		return rbsize;
	}

	public void setRbsize(int rbsize) {
		this.rbsize = rbsize;
	}

	public int getRspage() {
		return rspage;
	}

	public void setRspage(int rspage) {
		this.rspage = rspage;
	}

	public int getRepage() {
		return repage;
	}

	public void setRepage(int repage) {
		this.repage = repage;
	}

	public int getRrcnt() {
		return rrcnt;
	}

	public void setRrcnt(int rrcnt) {
		this.rrcnt = rrcnt;
	}

	public int getRpcnt() {
		return rpcnt;
	}

	public void setRpcnt(int rpcnt) {
		this.rpcnt = rpcnt;
	}
		
}
