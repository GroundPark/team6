package vo;

public class MemberInfo {
	// 한 명의 회원 정보를 저장할 클래스
	private int mi_idx, mi_point;
	private String mi_id, mi_pw, mi_name, mi_gender, mi_birth, mi_phone, mi_email, mi_grade, mi_recommend, mi_date, mi_isact, mi_hand;
	public int getMi_idx() {
		return mi_idx;
	}
	public void setMi_idx(int mi_idx) {
		this.mi_idx = mi_idx;
	}
	public int getMi_point() {
		return mi_point;
	}
	public void setMi_point(int mi_point) {
		this.mi_point = mi_point;
	}
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getMi_pw() {
		return mi_pw;
	}
	public void setMi_pw(String mi_pw) {
		this.mi_pw = mi_pw;
	}
	public String getMi_name() {
		return mi_name;
	}
	public void setMi_name(String mi_name) {
		this.mi_name = mi_name;
	}
	public String getMi_gender() {
		return mi_gender;
	}
	public void setMi_gender(String mi_gender) {
		this.mi_gender = mi_gender;
	}
	public String getMi_birth() {
		return mi_birth;
	}
	public void setMi_birth(String mi_birth) {
		this.mi_birth = mi_birth;
	}
	public String getMi_phone() {
		return mi_phone;
	}
	public void setMi_phone(String mi_phone) {
		this.mi_phone = mi_phone;
	}
	public String getMi_email() {
		return mi_email;
	}
	public void setMi_email(String mi_email) {
		this.mi_email = mi_email;
	}
	public String getMi_grade() {
		return mi_grade;
	}
	public void setMi_grade(String mi_grade) {
		this.mi_grade = mi_grade;
	}
	public String getMi_recommend() {
		return mi_recommend;
	}
	public void setMi_recommend(String mi_recommend) {
		this.mi_recommend = mi_recommend;
	}
	public String getMi_date() {
		return mi_date;
	}
	public void setMi_date(String mi_date) {
		this.mi_date = mi_date;
	}
	public String getMi_isact() {
		return mi_isact;
	}
	public void setMi_isact(String mi_isact) {
		this.mi_isact = mi_isact;
	}
	public String getMi_hand() {
		return mi_hand;
	}
	public void setMi_hand(String mi_hand) {
		this.mi_hand = mi_hand;
	}
	
}
