package vo;

public class ReviewInfo {
	private String mi_id, rl_content, pi_name, rl_date;
	private int rl_score, rl_good;
	
	
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getRl_content() {
		return rl_content;
	}
	public void setRl_content(String rl_content) {
		this.rl_content = rl_content;
	}
	public String getPi_name() {
		return pi_name;
	}
	public void setPi_name(String pi_name) {
		this.pi_name = pi_name;
	}
	public String getRl_date() {
		return rl_date;
	}
	public void setRl_date(String rl_date) {
		this.rl_date = rl_date;
	}
	public int getRl_score() {
		return rl_score;
	}
	public void setRl_score(int rl_score) {
		this.rl_score = rl_score;
	}
	public int getRl_good() {
		return rl_good;
	}
	public void setRl_good(int rl_good) {
		this.rl_good = rl_good;
	}
	
	
}
