package vo;
// 리스트 아닌데 왜 리스트냐하면 복붙을 했기때문... 되면 바꿈
public class ChallengeGoodList {
	private String mi_id;
	private int cg_idx, ci_idx, cg_history;
	
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public int getCg_idx() {
		return cg_idx;
	}
	public void setCg_idx(int cg_idx) {
		this.cg_idx = cg_idx;
	}
	public int getCi_idx() {
		return ci_idx;
	}
	public void setCi_idx(int ci_idx) {
		this.ci_idx = ci_idx;
	}
	public int getCg_history() {
		return cg_history;
	}
	public void setCg_history(int cg_history) {
		this.cg_history = cg_history;
	}
	
	
}
