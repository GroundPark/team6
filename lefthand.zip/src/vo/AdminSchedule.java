package vo;

public class AdminSchedule {
	private int as_idx;
	private String ai_id, as_title, as_stime, as_content, as_date;
	
	
	public int getAs_idx() {
		return as_idx;
	}
	public void setAs_idx(int as_idx) {
		this.as_idx = as_idx;
	}
	public String getAi_id() {
		return ai_id;
	}
	public void setAi_id(String ai_id) {
		this.ai_id = ai_id;
	}
	public String getAs_title() {
		return as_title;
	}
	public void setAs_title(String as_title) {
		this.as_title = as_title;
	}
	public String getAs_stime() {
		return as_stime;
	}
	public void setAs_stime(String as_stime) {
		this.as_stime = as_stime;
	}
	public String getAs_content() {
		return as_content;
	}
	public void setAs_content(String as_content) {
		this.as_content = as_content;
	}
	public String getAs_date() {
		return as_date;
	}
	public void setAs_date(String as_date) {
		this.as_date = as_date;
	}

}
